interface Window {
  __EXCALIDRAW_SHA__: string | undefined;
}
