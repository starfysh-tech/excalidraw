import InteractiveCanvas from "./InteractiveCanvas";
import StaticCanvas from "./StaticCanvas";

export { InteractiveCanvas, StaticCanvas };
